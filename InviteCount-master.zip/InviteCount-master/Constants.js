const Links = {
    DISCORD: "https://discord.gg/N99PJgE",
    DASHBOARD: "https://dash.manage-invite.xyz"
};

module.exports = {
    Links
};